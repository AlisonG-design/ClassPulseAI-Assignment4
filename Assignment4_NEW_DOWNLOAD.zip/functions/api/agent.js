// Cloudflare Pages Function. The API key is a SERVER-SIDE Cloudflare secret.
const MODEL = 'gpt-4.1-mini';
const FIELDS = ['grade','behavior','desired','context','strengths','strategies','measure','type','value','period','request'];
const RISK_URGENT = /\b(immediate danger|imminent danger|immediate threat|active threat|about to hurt|threatening to hurt|suicid(?:e|al)|self[- ]harm|abuse disclosure|disclosed abuse|reports abuse)\b/i;
const RISK_REVIEW = /\b(diagnos(?:e|is)|prescrib\w*|medication|restraint|restrain|seclusion|seclude|suspend|expel|punish(?:ment)?|abuse)\b/i;
const ACTIONS = ['CLARIFY','CLARIFY_BASELINE','CLARIFY_MEASURE','HUMAN_REVIEW','URGENT_HUMAN_REVIEW','SELECT_SUPPORT'];
const HEADERS={'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'};
function reply(body,status=200){return new Response(JSON.stringify(body),{status,headers:HEADERS});}
function normalize(src){ const out={}; for(const k of FIELDS)out[k]=typeof src?.[k]==='string'?src[k].trim().slice(0,1200):'';return out; }
function safeguard(x){
 const riskText=[x.request,x.behavior,x.desired].join(' ');
 if(RISK_URGENT.test(riskText))return {action:'URGENT_HUMAN_REVIEW',reason:'Possible immediate danger or safeguarding emergency'};
 if(RISK_REVIEW.test(riskText)&& !/routine classroom safety reminders/i.test(riskText))return {action:'HUMAN_REVIEW',reason:'Request includes a sensitive clinical, restrictive or disciplinary decision'};
 const absent=['grade','behavior','desired'].filter(k=>!x[k]);if(absent.length)return {action:'CLARIFY',reason:`Missing required input: ${absent.join(', ')}`};
 const present=['measure','type','value','period'].filter(k=>x[k]);if(present.length>0&&present.length<4)return {action:'CLARIFY_BASELINE',reason:'Baseline fields are partially filled'};
 return null;
}
function stopOutput(action){
 return action==='URGENT_HUMAN_REVIEW'?'STOP. Do not generate a support plan. If anyone is in immediate danger, contact emergency services or the designated on-site crisis response immediately. Otherwise promptly contact the school safeguarding or crisis lead and follow applicable reporting procedures. Do not investigate disclosures with this tool.':'STOP. Refer this request to qualified school personnel under approved institutional procedures. I cannot diagnose or recommend restraint, seclusion, medication, or punitive discipline.';
}
function outputFor(action,x,result){
 if(action==='URGENT_HUMAN_REVIEW'||action==='HUMAN_REVIEW')return stopOutput(action);
 if(action==='CLARIFY'||action==='CLARIFY_BASELINE'||action==='CLARIFY_MEASURE')return String(result?.question||'Please clarify the missing or conflicting evidence before drafting.').slice(0,650);
 const baseline=x.measure&&x.type&&x.value&&x.period?`Only “${x.measure}” is measured: ${x.type}, ${x.value}, during ${x.period}. This is not evidence for other behaviors.`:'No complete baseline provided; do not establish numerical goals.';
 const supports=Array.isArray(result?.supports)?result.supports.filter(s=>typeof s==='string').slice(0,4).map(s=>s.slice(0,250)):[];
 return `DRAFT — EDUCATOR REVIEW REQUIRED\nGrade: ${x.grade}\nTarget behavior: ${x.behavior}\nDesired behavior: ${x.desired}\nEvidence: ${baseline}\nPossible supports for educator review:\n${supports.map((s,i)=>`${i+1}. ${s}`).join('\n')||'Discuss possible supports with the educator.'}\nMonitoring: ${String(result?.monitoring||'Gather comparable observation data before setting numerical goals.').slice(0,400)}\nNo diagnoses, invented baseline, causal certainty or autonomous student-level decisions. Educator approval required.`;
}
const INSTRUCTIONS = `You are ClassPulseAI, one bounded educational support DECISION AGENT, not a clinician or disciplinarian. Only use supplied fictional/de-identified classroom evidence. Select EXACTLY ONE next action based on meaning and context, not a fixed sequence: CLARIFY (essential educational info missing or unclear), CLARIFY_BASELINE (incomplete baseline), CLARIFY_MEASURE (baseline tracks a different behavior from the target, including semantic mismatches), HUMAN_REVIEW (diagnosis, medication, restraint, seclusion, punitive decisions), URGENT_HUMAN_REVIEW (immediate threat, self-harm, safeguarding), SELECT_SUPPORT (adequate context for bounded, non-prescriptive strategies). Do not infer that frequency for talking applies to seat-leaving. Do not invent data or numerical goals. A mention of benign classroom safety routines is not by itself cause for refusal. For clarification ask one concrete question. For SELECT_SUPPORT choose 2-4 distinct, feasible instructional supports tied to context, observed behavior, strengths and desired behavior; explain monitoring without false precision. Always stop on risk. Return ONLY a JSON object: {"action":"ONE_OF_ALLOWED_ACTIONS","reason":"brief","question":"string (if clarify)","supports":["support 1","support 2"],"monitoring":"string"}. No markdown.`;
function extractText(data){ if(typeof data?.output_text==='string')return data.output_text;return (data?.output||[]).flatMap(item=>(item.content||[]).filter(c=>c.type==='output_text').map(c=>c.text||'')).join(''); }
function validateDecision(raw){const o=JSON.parse(raw);if(!o||!ACTIONS.includes(o.action)||typeof o.reason!=='string')throw Error('Invalid agent decision');if(o.action==='SELECT_SUPPORT'&&(!Array.isArray(o.supports)||o.supports.length<1))throw Error('No selected supports');return o;}
export async function onRequestPost({request,env}){
 if(!env.OPENAI_API_KEY)return reply({error:'OpenAI API secret not configured. Deployment administrator must add OPENAI_API_KEY.'},503);
 let payload;try{if(Number(request.headers.get('content-length'))>15000)return reply({error:'Request too large'},413);payload=await request.json();}catch{return reply({error:'Invalid JSON'},400);}
 const x=normalize(payload?.input);if(Object.values(x).some(v=>v.length>=1200))return reply({error:'Please shorten entries to under 1200 characters.'},400);
 const gate=safeguard(x);
 // Deterministic controls are the final safety floor, not the agent action selector for normal requests.
 if(gate?.action==='URGENT_HUMAN_REVIEW'||gate?.action==='HUMAN_REVIEW')return reply({status:'human_review',decision:gate,output:stopOutput(gate.action),source:'safety_override',model:null});
 if(gate?.action==='CLARIFY'||gate?.action==='CLARIFY_BASELINE')return reply({status:'clarify',decision:gate,output:gate.reason+'. Please provide the missing information, or clear all baseline fields for a non-numerical draft.',source:'validation_override',model:null});
 const modelRequest={model:MODEL,max_output_tokens:750,instructions:INSTRUCTIONS,input:JSON.stringify(x)};
 let modelResult;
 try{const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{authorization:`Bearer ${env.OPENAI_API_KEY}`,'content-type':'application/json'},body:JSON.stringify(modelRequest)});if(!r.ok)throw Error(`Upstream API status ${r.status}`);modelResult=validateDecision(extractText(await r.json()));}
 catch(e){return reply({error:'The agent could not produce a validated decision. No support plan was generated.',detail:'Retry later or ask an educator.'},502);}
 let action=modelResult.action; // semantic mismatch and context-sensitive support choice come from LLM.
 if(action==='SELECT_SUPPORT'&&!(x.measure&&x.type&&x.value&&x.period)&&/\b\d+\s*%|\btarget of \d+/i.test(JSON.stringify(modelResult)))return reply({error:'Unverified numerical target detected. No draft produced.'},502);
 // Hard safety guard: a model cannot override validations or stop conditions.
 const status=['HUMAN_REVIEW','URGENT_HUMAN_REVIEW'].includes(action)?'human_review':action.startsWith('CLARIFY')?'clarify':'draft';
 return reply({status,decision:{action,reason:modelResult.reason},output:outputFor(action,x,modelResult),source:'llm',model:MODEL});
}
export const __test={normalize,safeguard,validateDecision,extractText,outputFor};
